﻿using DiffMatchPatch;
using System;

namespace Assignment_2
{
    class Program
    {
        static void Main(string[] args)
        {
            diff_match_patch patch = new diff_match_patch();
            // The name of the first file is entered for comparison
            Console.WriteLine("Enter path to the first file: ");
            //Allows user to enter the name of the files 
            string f1 = Console.ReadLine();
            //Name of second file for comparison is entered
            Console.WriteLine("Enter path to the second file: ");
            //Allows user to enter the name of the second file
            string f2 = Console.ReadLine();
            MyDiff diff = new MyDiff(f1, f2);
            //Comparison of the two files
            diff.compare();
            // if the files do not exist
            Console.WriteLine("Enter any character:");
            Console.ReadKey(true);
        }
    }
}
