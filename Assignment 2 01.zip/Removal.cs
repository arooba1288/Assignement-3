﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    /// <summary>
    /// A class to represent a removal change.
    /// For example if a.txt is "Hello world" and b.txt is "Hello", 
    /// the change will be as:
    /// index=6, length=5
    /// line=Hello world
    /// lineNumber=0
    /// </summary>
    class Removal : Change
    {

        /// <summary>
        /// Creates a default <code>Removal</code>object with default values for the
        /// instance variables.
        /// </summary>
        public Removal()
            : base()
        {

        }

        /// <summary>
        /// Creates an object of type Removal with the passed parameters
        /// </summary>
        /// <param name="index">The starting point of the change</param>
        /// <param name="length">The number of characters that have changed</param>
        /// <param name="lineNumber">The line where this change occurs</param>
        /// <param name="line">The line that contains the change</param>
        public Removal(int index, int length, int lineNumber, string line)
            : base(index, length, lineNumber, line)
        { }
    }
}