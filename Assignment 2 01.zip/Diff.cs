﻿using DiffMatchPatch;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    class MyDiff
    {
        /// <summary>
        /// The changes in the two files are stored in this list
        /// </summary>
        private List<Change> changes = new List<Change>();
        /// <summary>
        /// The path to the first file.
        /// </summary>
        private string f1;
        /// <summary>
        /// The path to the second file
        /// </summary>
        private string f2;

        /// <summary>
        /// Create MyDiff object. The file paths are set to empty strings
        /// </summary>
        public MyDiff()
        {
            setF1("");
            setF2("");
        }

        /// <summary>
        /// Create a <code>MyDiff</code> object and initialize it properly
        /// </summary>
        /// <param name="f1"></param>
        /// <param name="f2"></param>
        public MyDiff(string f1, string f2)
        {
            setF2(f2);
            setF1(f1);
        }

        /// <summary>
        /// Set the path to the first file.
        /// </summary>
        /// <param name="f1">The path to set</param>
        public void setF1(string f1)
        {
            this.f1 = f1;
        }

        /// <summary>
        /// Set the path to the second file
        /// </summary>
        /// <param name="f2">The path to set</param>
        public void setF2(string f2)
        {
            this.f2 = f2;
        }

        /// <summary>
        /// Compare the two files and print their differences.
        /// </summary>
        public void compare()
        {
            compare(f1, f2);
        }

        /// <summary>
        /// Compare two files and print the differences.
        /// </summary>
        /// <param name="f1">The path to the first file</param>
        /// <param name="f2">The path to the second file</param>
        public void compare(string f1, string f2)
        {
            diff_match_patch patch = new diff_match_patch();

            try
            {
                string[] lines1 = File.ReadAllLines(f1);
                string[] lines2 = File.ReadAllLines(f2);
                for (int j = 0; j < Math.Max(lines1.Length, lines2.Length); j++)
                {
                    string l1 = ""; string l2 = "";
                    if (j < lines1.Length)
                    {
                        l1 = lines1[j];
                    }
                    if (j < lines2.Length)
                    {
                        l2 = lines2[j];
                    }

                    List<Patch> p = patch.patch_make(l1, l2);

                    foreach (Patch item in p)
                    {
                        List<Diff> diffs = item.diffs;
                        foreach (Diff diff in diffs)
                        {
                            if (diff.operation == Operation.DELETE)
                            {
                                Removal removal = new Removal();
                                removal.setIndex(l1.IndexOf(diff.text, item.start1 - 1));
                                removal.setLength(diff.text.Length);
                                removal.setLine(l1);
                                removal.setLineNumber(j);
                                removal.setOriginalLine(l1);
                                changes.Add(removal);
                            }
                            else if (diff.operation == Operation.INSERT)
                            {
                                Addition addition = new Addition();
                                addition.setIndex(l2.IndexOf(diff.text, item.start2 - 1));
                                addition.setLength(diff.text.Length);
                                addition.setLine(l2);
                                addition.setLineNumber(j);
                                addition.setOriginalLine(l2);
                                changes.Add(addition);
                            }
                        }
                    }

                }
                printChanges();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Print a summary of the changes.
        /// </summary>
        private void printChanges()
        {
            foreach (Change change in changes)
            {
                Console.Write("\tLine " + (change.getLineNumber() + 1) + ": ");
                if (change is Removal)
                {
                    for (int i = 0; i < change.getLine().Length; i++)
                    {
                        if (i == change.getIndex())
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                        }
                        else if (i == change.getIndex() + change.getLength())
                        {
                            Console.ResetColor();
                        }
                        Console.Write(change.getLine()[i]);
                    }
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine();
                    Console.WriteLine("\t-" + change.getLine().Substring(change.getIndex(), change.getLength()));
                    Console.ResetColor();
                }
                else if (change is Addition)
                {
                    for (int i = 0; i < change.getLine().Length; i++)
                    {
                        if (i == change.getIndex())
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                        }
                        else if (i == change.getIndex() + change.getLength())
                        {
                            Console.ResetColor();
                        }
                        Console.Write(change.getLine()[i]);
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine();
                    Console.WriteLine("\t+" + change.getLine().Substring(change.getIndex(), change.getLength()));
                    Console.ResetColor();
                }

            }
        }
    }
}