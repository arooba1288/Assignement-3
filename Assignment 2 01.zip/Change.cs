﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    abstract class Change
    {
        /// <summary>
        /// The starting index of the change
        /// </summary>
        private int index;
        /// <summary>
        /// The line containing this change
        /// </summary>
        private String line;
        /// <summary>
        /// The number of characters that have changed.
        /// </summary>
        private int length;
        /// <summary>
        /// The line where this change occurs
        /// </summary>
        private int lineNumber;
        /// <summary>
        /// The line that was changed. i.e. the original line
        /// </summary>
        private string originalLine;

        /// <summary>
        /// Creates a default object of this class
        /// </summary>
        public Change()
        {
            index = -1;
            line = "";
            length = -1;
            lineNumber = -1;
        }

        /// <summary>
        /// Creates an object of this class and initializes the instance variables
        /// </summary>
        /// <param name="index">The starting index of the word that will be highlighted</param>
        /// <param name="length">The number of characters that have changed</param>
        /// <param name="lineNumber">The line where this change occured</param>
        /// <param name="line">The line containing this change</param>
        public Change(int index, int length, int lineNumber, String line)
        {
            this.index = index;
            this.line = line;
            this.length = length;
            this.lineNumber = lineNumber;
        }

        /// <summary>
        /// Get the line that contains this change
        /// </summary>
        /// <returns>A string containg the line that represents this change</returns>
        public String getLine()
        {
            return line;
        }

        /// <summary>
        /// Get the index of the word containg the change
        /// </summary>
        /// <returns>The index</returns>
        public int getIndex()
        {
            return index;
        }

        /// <summary>
        /// Set the starting index of the word that is changed
        /// </summary>
        /// <param name="index">The starting index</param>
        public void setIndex(int index)
        {
            this.index = index;
        }

        /// <summary>
        /// The line that contains this change
        /// </summary>
        /// <param name="line">The line to set</param>
        public void setLine(String line)
        {
            this.line = line;
        }

        /// <summary>
        /// Sets the length (the number of characters that have changed)
        /// </summary>
        /// <param name="length">The length to set</param>
        public void setLength(int length)
        {
            this.length = length;
        }

        /// <summary>
        /// Sets the line number of the line that contains this change
        /// </summary>
        /// <param name="lineNumber">The line number to set</param>
        public void setLineNumber(int lineNumber)
        {
            this.lineNumber = lineNumber;
        }

        /// <summary>
        /// The number of characters represented by this change
        /// </summary>
        /// <returns>The number of characters</returns>
        public int getLength()
        {
            return length;
        }

        /// <summary>
        /// Get the line where this change occured.
        /// Line indexing is 0 based.
        /// </summary>
        /// <returns>The line number.</returns>
        public int getLineNumber()
        {
            return lineNumber;
        }

        /// <summary>
        /// Set the original unchanged line.
        /// </summary>
        /// <param name="line">The line to set</param>
        public void setOriginalLine(string line)
        {
            originalLine = line;
        }

        /// <summary>
        /// Get the original unchanged line
        /// </summary>
        /// <returns>The original unchanged line</returns>
        public string getOriginalLine()
        {
            return originalLine;
        }
    }
}