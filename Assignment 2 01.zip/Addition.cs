﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    /// <summary>
    /// A class to represent an addition change.
    /// For example if a.txt is "Hello" and b.txt is "Hello world", 
    /// the change will be as:
    /// index=6, length=5
    /// line=Hello world
    /// lineNumber=1
    /// </summary>
    class Addition : Change
    {
        /// <summary>
        /// Creates a default <code>Addition</code>object with default values for the
        /// instance variables.
        /// </summary>
        public Addition()
            : base()
        {

        }

        /// <summary>
        /// Creates an object of type Addition with the passed parameters
        /// </summary>
        /// <param name="index">The starting point of the change</param>
        /// <param name="length">The number of characters that have changed</param>
        /// <param name="lineNumber">The line where this change occured.</param>
        /// <param name="line">The line that contains the change</param>
        public Addition(int index, int length, int lineNumber, string line)
            : base(index, length, lineNumber, line)
        { }
    }
}